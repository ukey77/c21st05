const config = {
    port: 3333,
    hostname: "localhost"
}

module.exports = config;