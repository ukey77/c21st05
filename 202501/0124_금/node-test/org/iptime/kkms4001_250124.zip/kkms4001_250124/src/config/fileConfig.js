const fileConfig = {
    fileMode: null,
    filePath: null,
    fileData: null
}

module.exports = fileConfig;