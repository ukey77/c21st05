const user = {
    id: null,
    pw: null
}

module.exports = user;